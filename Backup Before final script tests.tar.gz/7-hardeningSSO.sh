#!/usr/bin/env bash
set -euo pipefail
shopt -s inherit_errexit nullglob

# =========================================================
#  Final Hardening + SSO Integration
# =========================================================

# --- 1. COLOR VARIABLES ---
YW="$(printf '\033[33m')"
BL="$(printf '\033[36m')"
RD="$(printf '\033[01;31m')"
GN="$(printf '\033[1;92m')"
CL="$(printf '\033[m')"
CLF="$(printf '\033[5m')"
BFR="\\r\\033[K"

HOLD="-"
CM="${GN}✓${CL}"
WARN="${YW}!${CL}"
CROSS="${RD}✗${CL}"
BORDER="${BL}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${CL}"

# --- 2. GLOBAL VARIABLES ---
T=15

LOG_FILE="/var/log/final-hardening-sso.log"
RUNTIME_LOG_FILE=""
VERIFY_LOG="/var/log/final-hardening-sso-verify.log"
COMPLETED_MARKER="/root/.final-hardening-sso-completed"

DEFAULT_DOCKER_USER="${SUDO_USER:-orik}"
DOCKER_USER="${DOCKER_USER:-$DEFAULT_DOCKER_USER}"
DOCKER_DIR="${DOCKER_DIR:-/home/${DOCKER_USER}/docker}"
COMPOSE_DIR="${COMPOSE_DIR:-${DOCKER_DIR}/compose}"
ENV_FILE="${ENV_FILE:-${DOCKER_DIR}/.env}"

DOMAIN=""
ADMIN_UI="auto"
PORTAINER_SELECTED="no"
DOCKGE_SELECTED="no"
KOMODO_SELECTED="no"

SUDO_CMD=""
DOCKER_NEEDS_SUDO="no"

TRAEFIK_CONFIG_OK="no"
AUTHENTIK_CONTAINERS_OK="no"
AUTHENTIK_FORWARD_AUTH_OK="no"
AUTHENTIK_OUTPOST_302_OK="no"
PORTAINER_BOOTSTRAP_CLOSED="not-applicable"
UFW_PORTAINER_RULE_REMOVED="not-applicable"
NOPASSWD_HARDENED="no"
DOCKER_USER_RULES_REVIEWED="no"

TEMP_FILES=()

# =========================================================
#  OUTPUT HELPERS
# =========================================================

# --- 3. HEADER ---
function header_info() {
echo -e "${BL}
███████╗██╗███╗   ██╗ █████╗ ██╗         ██╗  ██╗ █████╗ ██████╗ ██████╗ ███████╗███╗   ██╗
██╔════╝██║████╗  ██║██╔══██╗██║         ██║  ██║██╔══██╗██╔══██╗██╔══██╗██╔════╝████╗  ██║
█████╗  ██║██╔██╗ ██║███████║██║         ███████║███████║██████╔╝██║  ██║█████╗  ██╔██╗ ██║
██╔══╝  ██║██║╚██╗██║██╔══██║██║         ██╔══██║██╔══██║██╔══██╗██║  ██║██╔══╝  ██║╚██╗██║
██║     ██║██║ ╚████║██║  ██║███████╗    ██║  ██║██║  ██║██║  ██║██████╔╝███████╗██║ ╚████║
╚═╝     ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚═╝  ╚═══╝
${CL}"
}

function msg_info() { echo -ne " ${HOLD} ${YW}$1...${CL}"; }
function msg_ok() { echo -e "${BFR} ${CM} ${GN}$1${CL}"; }
function msg_warn() { echo -e "${BFR} ${WARN} ${YW}$1${CL}"; }
function msg_skip() { echo -e "${BFR} ${WARN} ${YW}$1${CL}"; }
function msg_error() { echo -e "${BFR} ${CROSS} ${RD}$1${CL}"; exit 1; }

function section() {
    echo ""
    echo -e "${BORDER}"
    echo -e "${BL}$1${CL}"
    echo -e "${BORDER}"
}

function section_flash_success() {
    echo ""
    echo -e "${BORDER}"
    echo -e "${GN}${CLF}$1${CL}"
    echo -e "${BORDER}"
}

function detail_line() {
    local label="$1"
    local value="$2"
    echo -e " ${BL}━━━━━▶${CL} ${label}: ${GN}${value}${CL}"
}

function tty_print() {
    if [ -w /dev/tty ]; then
        echo -ne "$*" > /dev/tty
    else
        echo -ne "$*" >&2
    fi
}

function tty_println() {
    if [ -w /dev/tty ]; then
        echo -e "$*" > /dev/tty
    else
        echo -e "$*" >&2
    fi
}

# =========================================================
#  CLEANUP / ERROR HANDLING
# =========================================================

# --- 4. CLEANUP ---
function cleanup() {
    local exit_code="$?"
    local file=""

    if [ -n "${SUDO_CMD:-}" ] && [ -n "${RUNTIME_LOG_FILE:-}" ] && [ -s "$RUNTIME_LOG_FILE" ]; then
        "$SUDO_CMD" cp "$RUNTIME_LOG_FILE" "$LOG_FILE" 2>/dev/null || true
        "$SUDO_CMD" chmod 0644 "$LOG_FILE" 2>/dev/null || true
    fi

    for file in "${TEMP_FILES[@]:-}"; do
        [ -n "$file" ] && [ -f "$file" ] && rm -f "$file" 2>/dev/null || true
    done

    exit "$exit_code"
}

function on_error() {
    local line_no="$1"
    echo -e "${RD}ERROR:${CL} Script failed at line ${line_no}. Check ${LOG_FILE}"
}

function run_cmd() {
    local description="$1"
    shift

    local err_file=""
    err_file="$(mktemp)"
    TEMP_FILES+=("$err_file")

    if [ -n "$SUDO_CMD" ]; then
        if ! "$SUDO_CMD" "$@" > /dev/null 2> "$err_file"; then
            echo ""
            echo -e "${RD}Command failed during:${CL} ${description}"
            echo -e "${YW}Command:${CL} sudo $*"
            echo ""
            echo -e "${RD}Real error:${CL}"
            cat "$err_file"
            rm -f "$err_file"
            exit 1
        fi
    else
        if ! "$@" > /dev/null 2> "$err_file"; then
            echo ""
            echo -e "${RD}Command failed during:${CL} ${description}"
            echo -e "${YW}Command:${CL} $*"
            echo ""
            echo -e "${RD}Real error:${CL}"
            cat "$err_file"
            rm -f "$err_file"
            exit 1
        fi
    fi

    rm -f "$err_file"
}

function run_optional() {
    if [ -n "$SUDO_CMD" ]; then
        "$SUDO_CMD" "$@" >/dev/null 2>&1 || true
    else
        "$@" >/dev/null 2>&1 || true
    fi
}

# =========================================================
#  PROMPT HELPERS
# =========================================================

# --- 5. PROMPT SYSTEM ---
function flush_input_buffer() {
    local junk=""
    local i=""

    [ -r /dev/tty ] || return 0

    for i in {1..20}; do
        if ! IFS= read -rsn1 -t 0.02 junk < /dev/tty 2>/dev/null; then
            break
        fi
    done
}

function yes_no_label() {
    local value="$1"

    if [[ "$value" =~ ^[Yy]$ ]]; then
        echo "yes"
    else
        echo "no"
    fi
}

function tty_read_yes_no_blocking() {
    local prompt="$1"
    local default="$2"
    local default_label="Y/n"
    local key=""

    if [[ "$default" =~ ^[Nn]$ ]]; then
        default_label="y/N"
    fi

    flush_input_buffer

    while true; do
        tty_print "${BFR}${YW}${prompt} (${default_label}): ${CL}"

        if [ -r /dev/tty ]; then
            IFS= read -rsn1 key < /dev/tty || true
        else
            IFS= read -rsn1 key || true
        fi

        if [[ -z "$key" ]]; then
            tty_print "${BFR}"
            echo "$default"
            flush_input_buffer
            return 0
        elif [[ "$key" =~ ^[YyNn]$ ]]; then
            tty_print "${BFR}"
            echo "$key"
            flush_input_buffer
            return 0
        fi
    done
}

function timed_yes_no() {
    local prompt="$1"
    local default="$2"
    local answer=""
    local key=""
    local default_label="Y/n"
    local final_label=""
    local deadline=""
    local now=""
    local remaining=""

    if [[ "$default" =~ ^[Nn]$ ]]; then
        default_label="y/N"
    fi

    flush_input_buffer
    deadline=$(( $(date +%s) + T ))

    while true; do
        now=$(date +%s)
        remaining=$(( deadline - now ))

        if [ "$remaining" -le 0 ]; then
            answer="$default"
            break
        fi

        tty_print "${BFR}${YW}${prompt} (${default_label}) [${remaining}s]${CL} "

        if [ -r /dev/tty ]; then
            if IFS= read -rsn1 -t 1 key < /dev/tty; then
                if [[ "$key" == " " ]]; then
                    answer="$(tty_read_yes_no_blocking "$prompt" "$default")"
                    break
                elif [[ "$key" =~ ^[YyNn]$ ]]; then
                    answer="$key"
                    break
                elif [[ -z "$key" ]]; then
                    answer="$default"
                    break
                fi
            fi
        else
            if IFS= read -rsn1 -t 1 key; then
                if [[ "$key" == " " ]]; then
                    answer="$(tty_read_yes_no_blocking "$prompt" "$default")"
                    break
                elif [[ "$key" =~ ^[YyNn]$ ]]; then
                    answer="$key"
                    break
                elif [[ -z "$key" ]]; then
                    answer="$default"
                    break
                fi
            fi
        fi
    done

    [ -z "$answer" ] && answer="$default"
    final_label="$(yes_no_label "$answer")"

    tty_print "${BFR}"
    tty_println "${CM} ${GN}${prompt} ${final_label}${CL}"
    flush_input_buffer

    echo "$answer"
}

function editable_input_loop() {
    local prompt="$1"
    local default="$2"
    local initial_value="${3:-}"
    local answer="$initial_value"
    local key=""

    flush_input_buffer

    while true; do
        tty_print "${BFR}${YW}${prompt} [default: ${default}]: ${CL}${answer}"

        if [ -r /dev/tty ]; then
            IFS= read -rsn1 key < /dev/tty || true
        else
            IFS= read -rsn1 key || true
        fi

        case "$key" in
            "")
                [ -z "$answer" ] && answer="$default"
                tty_print "${BFR}"
                echo "$answer"
                flush_input_buffer
                return 0
                ;;
            $'\177'|$'\b')
                answer="${answer%?}"
                ;;
            *)
                answer+="$key"
                ;;
        esac
    done
}

function timed_text_input() {
    local prompt="$1"
    local default="$2"
    local answer=""
    local key=""
    local deadline=""
    local now=""
    local remaining=""

    flush_input_buffer
    deadline=$(( $(date +%s) + T ))

    while true; do
        now=$(date +%s)
        remaining=$(( deadline - now ))

        if [ "$remaining" -le 0 ]; then
            answer="$default"
            break
        fi

        tty_print "${BFR}${YW}${prompt} [default: ${default}] [${remaining}s]: ${CL}"

        if [ -r /dev/tty ]; then
            if IFS= read -rsn1 -t 1 key < /dev/tty; then
                if [[ "$key" == " " ]]; then
                    answer="$(editable_input_loop "$prompt" "$default" "")"
                    break
                elif [[ -z "$key" ]]; then
                    answer="$default"
                    break
                else
                    answer="$(editable_input_loop "$prompt" "$default" "$key")"
                    break
                fi
            fi
        else
            if IFS= read -rsn1 -t 1 key; then
                if [[ "$key" == " " ]]; then
                    answer="$(editable_input_loop "$prompt" "$default" "")"
                    break
                elif [[ -z "$key" ]]; then
                    answer="$default"
                    break
                else
                    answer="$(editable_input_loop "$prompt" "$default" "$key")"
                    break
                fi
            fi
        fi
    done

    [ -z "$answer" ] && answer="$default"

    tty_print "${BFR}"
    tty_println "${CM} ${GN}${prompt} ${answer}${CL}"
    flush_input_buffer

    echo "$answer"
}

# =========================================================
#  INIT / VALIDATION
# =========================================================

# --- 6. ROOT / SUDO / LOGGING ---
function detect_root_or_sudo() {
    if [ "$EUID" -eq 0 ]; then
        SUDO_CMD=""
    else
        SUDO_CMD="sudo"
    fi
}

function validate_sudo_access() {
    if [ -n "$SUDO_CMD" ]; then
        msg_info "Validating sudo access"

        if "$SUDO_CMD" -n true >/dev/null 2>&1; then
            msg_ok "PASSWORDLESS SUDO CONFIRMED"
            return 0
        fi

        if "$SUDO_CMD" -v; then
            msg_ok "SUDO ACCESS CONFIRMED"
            return 0
        fi

        msg_error "Sudo authentication failed. Script cancelled."
    fi
}

function init_logging() {
    if [ -n "$SUDO_CMD" ]; then
        RUNTIME_LOG_FILE="$(mktemp /tmp/final-hardening-sso-log.XXXXXX)"
        TEMP_FILES+=("$RUNTIME_LOG_FILE")
        exec > >(tee -a "$RUNTIME_LOG_FILE") 2>&1
    else
        RUNTIME_LOG_FILE="$LOG_FILE"
        exec > >(tee -a "$LOG_FILE") 2>&1
    fi
}

function validate_dependencies() {
    local required_commands=(
        awk
        cat
        chmod
        curl
        date
        docker
        grep
        id
        mkdir
        mktemp
        rm
        sed
        tee
    )

    local cmd=""

    for cmd in "${required_commands[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || msg_error "Required command not found: ${cmd}"
    done

    if [ -n "$SUDO_CMD" ]; then
        command -v sudo >/dev/null 2>&1 || msg_error "sudo is required when not running as root."
    fi
}

function init_script() {
    detect_root_or_sudo
    validate_sudo_access
    init_logging

    trap 'on_error "$LINENO"' ERR
    trap cleanup EXIT

    clear
    header_info

    validate_dependencies
}

# --- 7. DOCKER ACCESS ---
function detect_docker_access() {
    section "DOCKER ACCESS CHECK"

    msg_info "Checking Docker access"

    if docker ps >/dev/null 2>&1; then
        DOCKER_NEEDS_SUDO="no"
        msg_ok "DOCKER ACCESS CONFIRMED"
        detail_line "Docker mode" "current user"
        return 0
    fi

    if [ -n "$SUDO_CMD" ] && "$SUDO_CMD" docker ps >/dev/null 2>&1; then
        DOCKER_NEEDS_SUDO="yes"
        msg_ok "DOCKER ACCESS CONFIRMED WITH SUDO"
        detail_line "Docker mode" "sudo fallback"
        return 0
    fi

    msg_error "Docker daemon is not reachable. Run script 5 first."
}

function docker_cmd() {
    if [ "$DOCKER_NEEDS_SUDO" == "yes" ]; then
        "$SUDO_CMD" docker "$@"
    else
        docker "$@"
    fi
}

# =========================================================
#  CONFIG LOADING
# =========================================================

# --- 8. PROJECT CONFIG ---
function load_env_file() {
    section "PROJECT CONFIG"

    DOCKER_USER="$(timed_text_input "Enter Docker Linux user" "$DOCKER_USER")"
    DOCKER_DIR="$(timed_text_input "Enter Docker directory" "$DOCKER_DIR")"
    COMPOSE_DIR="$(timed_text_input "Enter compose directory" "$COMPOSE_DIR")"
    ENV_FILE="$(timed_text_input "Enter Docker .env path" "$ENV_FILE")"

    [ -f "$ENV_FILE" ] || msg_error ".env file not found: ${ENV_FILE}"

    # shellcheck disable=SC1090
    set -a
    . "$ENV_FILE"
    set +a

    DOMAIN="${DOMAIN:-}"

    [ -n "$DOMAIN" ] || msg_error "DOMAIN is missing from ${ENV_FILE}"

    detail_line "Docker user" "$DOCKER_USER"
    detail_line "Docker dir" "$DOCKER_DIR"
    detail_line "Compose dir" "$COMPOSE_DIR"
    detail_line "Domain" "$DOMAIN"
}

function detect_admin_ui() {
    section "ADMIN UI DETECTION"

    msg_info "Detecting selected admin UI"

    if docker_cmd ps -a --format '{{.Names}}' | grep -qx 'dockge'; then
        ADMIN_UI="dockge"
        DOCKGE_SELECTED="yes"
    elif docker_cmd ps -a --format '{{.Names}}' | grep -qx 'komodo-core'; then
        ADMIN_UI="komodo"
        KOMODO_SELECTED="yes"
    elif docker_cmd ps -a --format '{{.Names}}' | grep -qx 'portainer'; then
        ADMIN_UI="portainer"
        PORTAINER_SELECTED="yes"
    else
        ADMIN_UI="unknown"
    fi

    msg_ok "ADMIN UI DETECTION COMPLETE"
    detail_line "Selected admin UI" "$ADMIN_UI"

    if [ "$ADMIN_UI" == "unknown" ]; then
        msg_warn "No Dockge, Komodo, or Portainer container detected. Admin UI hardening will be skipped."
    fi
}

# =========================================================
#  PREFLIGHT
# =========================================================

# --- 9. STACK HEALTH CHECK ---
function verify_required_containers() {
    section "STACK HEALTH CHECK"

    local required_containers=(
        traefik
        authentik-server
        authentik-worker
        postgres
        redis
    )

    local container=""

    for container in "${required_containers[@]}"; do
        msg_info "Checking ${container}"

        if docker_cmd ps --format '{{.Names}}' | grep -qx "$container"; then
            msg_ok "${container} RUNNING"
        else
            msg_error "${container} is not running. Deploy core stacks before Script 7."
        fi
    done

    AUTHENTIK_CONTAINERS_OK="yes"
}

function start_confirmation() {
    local start_yn=""

    section "START"

    echo -e "${YW}This script finalizes Authentik/Traefik integration, closes bootstrap exposure, and applies final hardening checks.${CL}"
    echo -e "${YW}It should run only after all core stacks are deployed and working.${CL}"
    echo ""
    detail_line "Expected Authentik URL" "https://auth.${DOMAIN}"
    detail_line "Expected test domain" "https://portainer.${DOMAIN} or selected admin UI"
    echo ""

    start_yn="$(timed_yes_no "Start Final Hardening + SSO Integration?" "y")"

    if [[ "$start_yn" =~ ^[Nn] ]]; then
        exit 0
    fi
}

# =========================================================
#  TRAEFIK / AUTHENTIK VERIFICATION
# =========================================================

# --- 10. TRAEFIK CONFIG AUDIT ---
function verify_traefik_dynamic_config() {
    section "TRAEFIK CONFIG AUDIT"

    local dynamic_config="${DOCKER_DIR}/appdata/traefik/dynamic-config.yml"
    local static_config="${DOCKER_DIR}/appdata/traefik/traefik.yml"

    [ -f "$dynamic_config" ] || msg_error "Traefik dynamic config not found: ${dynamic_config}"
    [ -f "$static_config" ] || msg_error "Traefik static config not found: ${static_config}"

    msg_info "Checking for stale authentik@docker references"
    if grep -q 'authentik@docker' "$dynamic_config"; then
        msg_error "Stale authentik@docker reference found in dynamic-config.yml. Use authentik@file / authentik middleware instead."
    fi
    msg_ok "NO STALE AUTHENTIK@DOCKER REFERENCES"

    msg_info "Checking Authentik forwardAuth middleware"
    if grep -q 'forwardAuth:' "$dynamic_config" \
        && grep -q 'authentik-server:9000/outpost.goauthentik.io/auth/traefik' "$dynamic_config" \
        && grep -q 'maxResponseBodySize: 1048576' "$dynamic_config"; then
        msg_ok "AUTHENTIK FORWARDAUTH MIDDLEWARE FOUND"
    else
        msg_error "Authentik forwardAuth middleware is missing or incomplete."
    fi

    msg_info "Checking Authentik outpost callback router"
    if grep -q 'authentik-outpost:' "$dynamic_config" \
        && grep -q 'PathPrefix(`/outpost.goauthentik.io/`)' "$dynamic_config"; then
        msg_ok "AUTHENTIK OUTPOST CALLBACK ROUTER FOUND"
    else
        msg_error "Authentik outpost callback router missing from dynamic-config.yml."
    fi

    msg_info "Checking Traefik encoded-character configuration"
    if grep -q 'encodedCharacters:' "$static_config"; then
        msg_ok "TRAEFIK ENCODED-CHARACTER CONFIG FOUND"
    else
        msg_warn "Traefik encoded-character config not found. Add this to final Script 6 template fixes."
    fi

    TRAEFIK_CONFIG_OK="yes"
}

# --- 11. AUTHENTIK OUTPOST 302 TEST ---
function verify_authentik_outpost_302() {
    section "AUTHENTIK OUTPOST VERIFICATION"

    local test_host=""
    local test_url=""
    local http_code=""

    if [ "$PORTAINER_SELECTED" == "yes" ]; then
        test_host="portainer.${DOMAIN}"
    elif [ "$DOCKGE_SELECTED" == "yes" ]; then
        test_host="dockge.${DOMAIN}"
    elif [ "$KOMODO_SELECTED" == "yes" ]; then
        test_host="komodo.${DOMAIN}"
    else
        test_host="traefik.${DOMAIN}"
    fi

    test_url="https://${test_host}/outpost.goauthentik.io/start?rd=https://${test_host}/"

    msg_info "Testing Authentik outpost route"
    http_code="$(curl -kLs -o /dev/null -w '%{http_code}' "$test_url" || true)"

    if [ "$http_code" == "302" ] || [ "$http_code" == "200" ]; then
        AUTHENTIK_OUTPOST_302_OK="yes"
        msg_ok "AUTHENTIK OUTPOST ROUTE RESPONDED (${http_code})"
    else
        AUTHENTIK_OUTPOST_302_OK="no"
        msg_warn "Authentik outpost test returned HTTP ${http_code:-none}"
        echo ""
        echo -e "${YW}Manual Authentik check required:${CL}"
        echo -e "${YW}Applications → Outposts → authentik Embedded Outpost → Edit${CL}"
        echo -e "${YW}Move Traefik Forward Auth application into Selected Applications, then Update.${CL}"
        echo ""
        echo -e "${YW}Retest:${CL}"
        echo -e "${GN}curl -Ik \"${test_url}\"${CL}"
    fi

    detail_line "Outpost test URL" "$test_url"
    detail_line "HTTP result" "${http_code:-none}"
}

# =========================================================
#  ADMIN UI HARDENING
# =========================================================

# --- 12. PORTAINER BOOTSTRAP PORT CLOSURE ---
function close_portainer_bootstrap_exposure() {
    section "PORTAINER BOOTSTRAP CLOSURE"

    if [ "$PORTAINER_SELECTED" != "yes" ]; then
        PORTAINER_BOOTSTRAP_CLOSED="not-applicable"
        msg_skip "PORTAINER NOT SELECTED; BOOTSTRAP CLOSURE SKIPPED"
        return 0
    fi

    local yml_01="${COMPOSE_DIR}/01-portainer-compose.yml"
    local yml_override="${COMPOSE_DIR}/01-portainer-bootstrap-override.yml"
    local close_yn=""

    if [ ! -f "$yml_01" ]; then
        PORTAINER_BOOTSTRAP_CLOSED="missing-compose"
        msg_warn "Portainer compose file not found: ${yml_01}"
        return 0
    fi

    if [ ! -f "$yml_override" ]; then
        PORTAINER_BOOTSTRAP_CLOSED="already-no-override"
        msg_ok "NO PORTAINER BOOTSTRAP OVERRIDE FILE FOUND"
        return 0
    fi

    echo -e "${YW}This redeploys Portainer without the bootstrap override so direct 9443 exposure closes.${CL}"
    echo -e "${YW}Traefik/AuthentiK domain access remains available.${CL}"
    echo ""

    close_yn="$(timed_yes_no "Close temporary Portainer bootstrap port now?" "y")"

    if [[ "$close_yn" =~ ^[Nn] ]]; then
        PORTAINER_BOOTSTRAP_CLOSED="user-skipped"
        msg_skip "PORTAINER BOOTSTRAP PORT CLOSURE SKIPPED"
        return 0
    fi

    msg_info "Redeploying Portainer without bootstrap override"
    docker_cmd compose --env-file "$ENV_FILE" -p portainer -f "$yml_01" up -d >/dev/null
    msg_ok "PORTAINER REDEPLOYED WITHOUT BOOTSTRAP OVERRIDE"

    msg_info "Checking direct Portainer 9443 mapping"
    if docker_cmd port portainer 9443/tcp >/dev/null 2>&1; then
        PORTAINER_BOOTSTRAP_CLOSED="not-confirmed"
        msg_warn "Portainer still appears to have direct 9443 mapping. Check compose labels/ports."
    else
        PORTAINER_BOOTSTRAP_CLOSED="yes"
        msg_ok "PORTAINER DIRECT BOOTSTRAP PORT CLOSED"
    fi
}

# --- 13. UFW CLEANUP ---
function remove_portainer_ufw_rule() {
    section "UFW BOOTSTRAP RULE CLEANUP"

    if [ "$PORTAINER_SELECTED" != "yes" ]; then
        UFW_PORTAINER_RULE_REMOVED="not-applicable"
        msg_skip "PORTAINER NOT SELECTED; UFW CLEANUP SKIPPED"
        return 0
    fi

    if ! command -v ufw >/dev/null 2>&1; then
        UFW_PORTAINER_RULE_REMOVED="ufw-not-found"
        msg_skip "UFW NOT FOUND; RULE CLEANUP SKIPPED"
        return 0
    fi

    if ! ufw status 2>/dev/null | grep -qi "Status: active" && ! { [ -n "$SUDO_CMD" ] && "$SUDO_CMD" ufw status 2>/dev/null | grep -qi "Status: active"; }; then
        UFW_PORTAINER_RULE_REMOVED="ufw-not-active"
        msg_skip "UFW NOT ACTIVE; RULE CLEANUP SKIPPED"
        return 0
    fi

    msg_info "Removing temporary Portainer 9443 UFW rule"
    run_optional ufw delete allow 9443/tcp
    UFW_PORTAINER_RULE_REMOVED="attempted"
    msg_ok "TEMPORARY PORTAINER UFW RULE REMOVAL ATTEMPTED"
}

# =========================================================
#  SYSTEM HARDENING
# =========================================================

# --- 14. SUDO HARDENING ---
function harden_sudo_nopasswd() {
    section "SUDO HARDENING"

    local harden_yn=""
    local sudoers_files=(
        "/etc/sudoers.d/90-cloud-init-users"
        "/etc/sudoers.d/99-${DOCKER_USER}-nopasswd"
        "/etc/sudoers.d/${DOCKER_USER}"
    )

    local file=""

    echo -e "${YW}This step looks for broad NOPASSWD sudo entries for ${DOCKER_USER}.${CL}"
    echo -e "${YW}It does not delete sudo access automatically unless you confirm.${CL}"
    echo ""

    for file in "${sudoers_files[@]}"; do
        if [ -f "$file" ] || { [ -n "$SUDO_CMD" ] && "$SUDO_CMD" test -f "$file" 2>/dev/null; }; then
            detail_line "Detected sudoers candidate" "$file"
        fi
    done

    harden_yn="$(timed_yes_no "Disable broad NOPASSWD sudo entries if found?" "n")"

    if [[ "$harden_yn" =~ ^[Nn] ]]; then
        NOPASSWD_HARDENED="user-skipped"
        msg_skip "SUDO NOPASSWD HARDENING SKIPPED"
        return 0
    fi

    for file in "${sudoers_files[@]}"; do
        if [ -f "$file" ] || { [ -n "$SUDO_CMD" ] && "$SUDO_CMD" test -f "$file" 2>/dev/null; }; then
            msg_info "Backing up ${file}"
            run_optional cp -n "$file" "${file}.bak.$(date +%Y%m%d%H%M%S)"
            msg_ok "BACKUP CREATED FOR ${file}"

            msg_info "Commenting NOPASSWD lines in ${file}"
            if [ -n "$SUDO_CMD" ]; then
                "$SUDO_CMD" sed -i -E '/NOPASSWD/ s/^/# disabled by final hardening: /' "$file" || true
            else
                sed -i -E '/NOPASSWD/ s/^/# disabled by final hardening: /' "$file" || true
            fi
            msg_ok "NOPASSWD LINES COMMENTED IN ${file}"
        fi
    done

    NOPASSWD_HARDENED="yes"
}

# --- 15. DOCKER-USER FIREWALL REVIEW ---
function docker_user_firewall_review() {
    section "DOCKER-USER FIREWALL REVIEW"

    echo -e "${YW}Docker can bypass UFW for published container ports.${CL}"
    echo -e "${YW}For this project, public access should normally be only Traefik on 80/443.${CL}"
    echo ""
    echo -e "${BL}Recommended later:${CL}"
    echo -e "${YW}Review DOCKER-USER rules after confirming every service works.${CL}"
    echo -e "${YW}Do not apply broad blocking automatically until all ports and flows are confirmed.${CL}"
    echo ""

    DOCKER_USER_RULES_REVIEWED="yes"
    msg_ok "DOCKER-USER FIREWALL REVIEW RECORDED"
}

# =========================================================
#  VERIFICATION / SUMMARY
# =========================================================

# --- 16. FINAL CONTAINER SUMMARY ---
function show_container_summary() {
    section "CONTAINER SUMMARY"

    docker_cmd ps --format 'table {{.Names}}\t{{.Status}}\t{{.Networks}}' || true
}

# --- 17. VERIFICATION REPORT ---
function create_verification_report() {
    section "VERIFICATION REPORT"

    msg_info "Writing final hardening verification report"

    if [ -n "$SUDO_CMD" ]; then
        "$SUDO_CMD" bash -c "cat > '$VERIFY_LOG'" <<EOF
--- FINAL HARDENING + SSO VERIFICATION REPORT ---
Date: $(date)
Docker user: $DOCKER_USER
Docker dir: $DOCKER_DIR
Compose dir: $COMPOSE_DIR
Domain: $DOMAIN
Admin UI: $ADMIN_UI

Results:
Traefik config OK: $TRAEFIK_CONFIG_OK
Authentik containers OK: $AUTHENTIK_CONTAINERS_OK
Authentik outpost 302 OK: $AUTHENTIK_OUTPOST_302_OK
Portainer bootstrap closed: $PORTAINER_BOOTSTRAP_CLOSED
UFW Portainer rule removed: $UFW_PORTAINER_RULE_REMOVED
NOPASSWD hardened: $NOPASSWD_HARDENED
DOCKER-USER review: $DOCKER_USER_RULES_REVIEWED
EOF
    else
        cat > "$VERIFY_LOG" <<EOF
--- FINAL HARDENING + SSO VERIFICATION REPORT ---
Date: $(date)
Docker user: $DOCKER_USER
Docker dir: $DOCKER_DIR
Compose dir: $COMPOSE_DIR
Domain: $DOMAIN
Admin UI: $ADMIN_UI

Results:
Traefik config OK: $TRAEFIK_CONFIG_OK
Authentik containers OK: $AUTHENTIK_CONTAINERS_OK
Authentik outpost 302 OK: $AUTHENTIK_OUTPOST_302_OK
Portainer bootstrap closed: $PORTAINER_BOOTSTRAP_CLOSED
UFW Portainer rule removed: $UFW_PORTAINER_RULE_REMOVED
NOPASSWD hardened: $NOPASSWD_HARDENED
DOCKER-USER review: $DOCKER_USER_RULES_REVIEWED
EOF
    fi

    {
        echo ""
        echo "Containers:"
        docker_cmd ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}\t{{.Networks}}' 2>/dev/null || true
        echo ""
        echo "Traefik recent warnings/errors:"
        docker_cmd logs traefik --tail=80 2>/dev/null | grep -E 'ERR|WRN|authentik@docker|middleware .* does not exist' || true
    } | if [ -n "$SUDO_CMD" ]; then "$SUDO_CMD" tee -a "$VERIFY_LOG" >/dev/null; else tee -a "$VERIFY_LOG" >/dev/null; fi

    msg_ok "FINAL HARDENING VERIFICATION REPORT WRITTEN"
}

# --- 18. COMPLETION MARKER ---
function write_completion_marker() {
    section "COMPLETION MARKER"

    msg_info "Writing completion marker"

    if [ -n "$SUDO_CMD" ]; then
        "$SUDO_CMD" bash -c "cat > '$COMPLETED_MARKER'" <<EOF
Final Hardening + SSO completed on: $(date)
Docker user: $DOCKER_USER
Docker dir: $DOCKER_DIR
Compose dir: $COMPOSE_DIR
Domain: $DOMAIN
Admin UI: $ADMIN_UI
Traefik config OK: $TRAEFIK_CONFIG_OK
Authentik containers OK: $AUTHENTIK_CONTAINERS_OK
Authentik outpost 302 OK: $AUTHENTIK_OUTPOST_302_OK
Portainer bootstrap closed: $PORTAINER_BOOTSTRAP_CLOSED
UFW Portainer rule removed: $UFW_PORTAINER_RULE_REMOVED
NOPASSWD hardened: $NOPASSWD_HARDENED
DOCKER-USER review: $DOCKER_USER_RULES_REVIEWED
Verify log: $VERIFY_LOG
EOF
    else
        cat > "$COMPLETED_MARKER" <<EOF
Final Hardening + SSO completed on: $(date)
Docker user: $DOCKER_USER
Docker dir: $DOCKER_DIR
Compose dir: $COMPOSE_DIR
Domain: $DOMAIN
Admin UI: $ADMIN_UI
Traefik config OK: $TRAEFIK_CONFIG_OK
Authentik containers OK: $AUTHENTIK_CONTAINERS_OK
Authentik outpost 302 OK: $AUTHENTIK_OUTPOST_302_OK
Portainer bootstrap closed: $PORTAINER_BOOTSTRAP_CLOSED
UFW Portainer rule removed: $UFW_PORTAINER_RULE_REMOVED
NOPASSWD hardened: $NOPASSWD_HARDENED
DOCKER-USER review: $DOCKER_USER_RULES_REVIEWED
Verify log: $VERIFY_LOG
EOF
    fi

    msg_ok "COMPLETION MARKER WRITTEN"
}

# --- 19. FINAL SUMMARY ---
function show_final_summary() {
    section_flash_success "     ━━━━━━━━━━━━━━━━━    FINISHED    ━━━━━━━━━━━━━━━━━"

    detail_line "DOMAIN" "$DOMAIN"
    detail_line "ADMIN UI" "$ADMIN_UI"
    detail_line "TRAEFIK CONFIG OK" "$TRAEFIK_CONFIG_OK"
    detail_line "AUTHENTIK CONTAINERS OK" "$AUTHENTIK_CONTAINERS_OK"
    detail_line "AUTHENTIK OUTPOST 302" "$AUTHENTIK_OUTPOST_302_OK"
    detail_line "PORTAINER BOOTSTRAP CLOSED" "$PORTAINER_BOOTSTRAP_CLOSED"
    detail_line "UFW PORTAINER RULE REMOVED" "$UFW_PORTAINER_RULE_REMOVED"
    detail_line "NOPASSWD HARDENED" "$NOPASSWD_HARDENED"
    detail_line "DOCKER-USER REVIEW" "$DOCKER_USER_RULES_REVIEWED"
    detail_line "VERIFY LOG" "$VERIFY_LOG"

    echo ""
    echo -e "${BL}IMPORTANT:${CL}"

    if [ "$AUTHENTIK_OUTPOST_302_OK" != "yes" ]; then
        echo -e "${YW}Authentik outpost verification did not pass. Attach the Traefik Forward Auth application/provider to the existing authentik Embedded Outpost, then rerun Script 7.${CL}"
    else
        echo -e "${GN}Authentik forward-auth outpost route is responding correctly.${CL}"
    fi

    echo ""
    echo -e "${YW}If all services are stable, the next future improvement is DOCKER-USER firewall hardening.${CL}"
    echo ""
}

# =========================================================
#  MAIN
# =========================================================

# --- 20. MAIN ORCHESTRATION ---
function main() {
    init_script

    detect_docker_access
    load_env_file
    detect_admin_ui
    verify_required_containers
    start_confirmation

    verify_traefik_dynamic_config
    verify_authentik_outpost_302

    close_portainer_bootstrap_exposure
    remove_portainer_ufw_rule

    harden_sudo_nopasswd
    docker_user_firewall_review

    show_container_summary
    create_verification_report
    write_completion_marker
    show_final_summary

    exit 0
}

main "$@"